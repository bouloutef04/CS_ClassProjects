public interface TheBank {

}
